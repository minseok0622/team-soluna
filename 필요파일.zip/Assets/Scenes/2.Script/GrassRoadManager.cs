using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GrassRoadManager : MonoBehaviour
{
    public List<GameObject> TreeList;

    public int Persent = 70;

    void Start()
    {
        for (int i = -7; i < 8; i++)
        {
            if(Random.Range(0, 100) < Persent)
            {
                continue;
            }

            int randat = Random.Range(0, TreeList.Count);
            GameObject copyobj = GameObject.Instantiate(TreeList[randat]);
            copyobj.transform.SetParent(this.transform);

            copyobj.transform.localPosition = new Vector3(i, 1, 0);
        }
    }


    void Update()
    {
        
    }
}
