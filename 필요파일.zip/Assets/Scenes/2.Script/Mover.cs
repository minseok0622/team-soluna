using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mover : MonoBehaviour
{
    public float speed = -0.1f;

    void Start()
    {
        if(this.tag == "Rift")
        {
            GameObject.Destroy(gameObject, 17f);
        }
        if (this.tag == "Car")
        {
            GameObject.Destroy(gameObject, 2f);
        }
    }

    void Update()
    {
        Vector3 temppos = transform.localPosition;
        temppos.x += speed * Time.deltaTime;
        transform.localPosition = temppos;

        //transform.Translate(speed * Time.deltaTime, 0, 0);
    }
}
