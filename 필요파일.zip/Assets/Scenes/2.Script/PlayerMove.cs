using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMove : MonoBehaviour
{
    public Transform Modeltrans;

    void Start()
    {
        
    }

    public void Restart()
    {

    }

    public void GameOver()
    {
        Debug.Log("���ӿ���");
    }

    //�浹
    private void OnTriggerEnter(Collider other)
    {
        Debug.Log($"�浹 : {other.tag}");
        if(other.tag == "Car")
        {
            GameOver();
        }
        if(other.tag == "Rift")
        {
            transform.SetParent(other.transform);
        }
    }

    private void OnTriggerExit(Collider other)
    {
        transform.SetParent(null);
    }

    void Update()
    {
        Vector3 moveval = Vector3.zero;

        //ĳ���� �����̱�
        if (Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.W))
        {
            //this.transform.Translate(0, 0, 1);

            RaycastHit hitinto;

            if(Physics.Raycast(transform.position
                , new Vector3(0, 0, 1)
                , out hitinto
                , 1f))
            {
                if (hitinto.transform.tag == "Car" || hitinto.transform.tag == "Rift")
                {
                    moveval.z = 1;
                }
            }
            else
            {
                moveval.z = 1;
            }

            Modeltrans.rotation = Quaternion.Euler(0, 0, 0);
        }

        if (Input.GetKeyDown(KeyCode.DownArrow) || Input.GetKeyDown(KeyCode.S))
        {
            //this.transform.Translate(0, 0, -1);
            RaycastHit hitinto;

            if (Physics.Raycast(transform.position
                , new Vector3(0, 0, -1)
                , out hitinto
                , 1f))
            {
                if (hitinto.transform.tag == "Car" || hitinto.transform.tag == "Rift")
                {
                    moveval.z = -1;
                }
            }
            else
            {
                moveval.z = -1;
            }

            Modeltrans.rotation = Quaternion.Euler(0, 180, 0);
        }

        if (Input.GetKeyDown(KeyCode.LeftArrow) || Input.GetKeyDown(KeyCode.A))
        {
            //this.transform.Translate(-1, 0, 0);
            RaycastHit hitinto;

            if (Physics.Raycast(transform.position
                , new Vector3(-1, 0, 0)
                , out hitinto
                , 1f))
            {
                if (hitinto.transform.tag == "Car" || hitinto.transform.tag == "Rift")
                {
                    moveval.x = -1;
                }
            }
            else
            {
                moveval.x = -1;
            }

            Modeltrans.rotation = Quaternion.Euler(0, -90, 0);
        }

        if (Input.GetKeyDown(KeyCode.RightArrow) || Input.GetKeyDown(KeyCode.D))
        {
            //this.transform.Translate(1, 0, 0);

            RaycastHit hitinto;

            if (Physics.Raycast(transform.position
                , new Vector3(1, 0, 0)
                , out hitinto
                , 1f))
            {
                if (hitinto.transform.tag == "Car" || hitinto.transform.tag == "Rift")
                {
                    moveval.x = 1;
                }
            }
            else
            {
                moveval.x = 1;
            }
            Modeltrans.rotation = Quaternion.Euler(0, 90, 0);
        }

        if(moveval.x == 0 && moveval.z == 0)
        {
            RaycastHit hitinto;
            if(Physics.Raycast(transform.position
                , new Vector3(0, -1, 0)
                , out hitinto
                , 1f))
            {
                if(hitinto.transform.tag == "Water")
                {
                    GameOver();
                }
            }
        }

        transform.Translate(moveval);

        int currentstep = (int)transform.position.z;

        if ( MaxStep < currentstep)
        {
            MaxStep = currentstep;

            if (transform.position.z >= 14f)
            {
                RoadManager manager = GameObject.FindObjectOfType<RoadManager>();
                //int z = (int)transform.position.z;
                //GameObject.Destroy(manager.RoadArr[z - 14]);

                //manager.RemoveLastRoad();
                //manager.CreateRoad(MaxStep - 14 + 40);
                manager.CreateFrontRoad(MaxStep - 14);
            }
        }
    }

    public int MaxStep = 0;
}
