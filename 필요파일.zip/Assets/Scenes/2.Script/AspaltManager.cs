using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AspaltManager : MonoBehaviour
{
    public GameObject Car;
    public Transform StPos;

    public int Persent = 70;

    void CrateCar()
    {
        if (Random.Range(0, 100) < Persent)
        {
            GameObject copyobj = GameObject.Instantiate(Car);
            copyobj.transform.position = StPos.position;
            
            //�θ𿡰� ���ӽ�Ű��
            copyobj.transform.SetParent(this.transform);

            //�� ���� �ٲٱ�
            copyobj.transform.localRotation = Quaternion.identity;
        }
    }

    void Start()
    {
        //�ٸ� ���
        //NextSec = DelaySec;

        if (Random.Range(0, 10) <= 5)
        {
            transform.rotation = Quaternion.Euler(0, 0, 0);
        }
        else if (Random.Range(0, 10) >= 6)
        {
            transform.rotation = Quaternion.Euler(0, 180, 0);
        }

        InvokeRepeating("CrateCar", 0, 1);
    }

    void Update()
    {
        //UpdateDelayCall()
    }

    //�ٸ� ���
    //float DelaySec = 1f;
    //float NextSec = 0f;
    //public bool m_ISDelayCall = false;

    //void UpdateDelayCall()
    //{
    //    if (m_ISDelayCall)
    //    {
    //        NextSec -= Time.deltaTime;
    //            if (NextSec <= 0)
    //            {
    //                NextSec = DelaySec;
    //                CrateCar();
    //            }
    //    }
    //}
}
