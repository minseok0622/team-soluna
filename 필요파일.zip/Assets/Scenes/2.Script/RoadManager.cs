using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoadManager : MonoBehaviour
{
    public List<GameObject> Ori_RoadList;

    public GameObject[] RoadArr;

    public List<GameObject> RoadList = new List<GameObject>();

    public int InitRoadCount = 45;

    void Start()
    {
        int count = InitRoadCount;
        RoadArr = new GameObject[count];

        for (int i = 0; i < count; i++)
        {
            //GameObject copyobj = GameObject.Instantiate(Road);
            //copyobj.transform.position = new Vector3(0, 0, i);
            //copyobj.name = $"Road{i}"; //"Road" + i.ToString 
            //RoadArr[i] = CreateRoad(i);

            //GameObject copyobj = CreateRoad(i);
            CreateRoad(i);
        }
    }

    public void RemoveLastRoad()
    {
        //GameObject.Destroy(RoadArr[0]);
        //RoadArr[0] = null;

        //for (int i = 1; i < 31; i++)
        //{
        //    RoadArr[i - 1] = RoadArr[i];
        //}

        //RoadArr[30] = null;

        GameObject.Destroy(RoadList[0]);
        RoadList.RemoveAt(0);
    }

    public GameObject CreateRoad(int p_z)
    {
        //�����ϰ� �ϳ� ������ ����
        int randat = Random.Range(0, Ori_RoadList.Count);
        GameObject obj = Ori_RoadList[randat];

        // ����
        GameObject copyobj = GameObject.Instantiate(obj);
        copyobj.transform.position = new Vector3(0, 0, p_z);
        copyobj.name = $"Road{p_z}";

        RoadList.Add(copyobj);

        return copyobj;
    }

    public void CreateFrontRoad(int p_z)
    {
        RemoveLastRoad();
        CreateRoad(p_z + InitRoadCount);
    }

    void Update()
    {
        
    }
}
