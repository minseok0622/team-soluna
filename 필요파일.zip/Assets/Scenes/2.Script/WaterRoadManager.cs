using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WaterRoadManager : MonoBehaviour
{
    public GameObject Rift;
    public Transform StPos;

    public int Persent = 70;

    void CrateRift()
    {
        if (Random.Range(0, 100) < Persent)
        {
            GameObject copyobj = GameObject.Instantiate(Rift);
            copyobj.transform.position = StPos.position;

            //�θ𿡰� ���ӽ�Ű��
            copyobj.transform.SetParent(this.transform);

            //�� ���� �ٲٱ�
            copyobj.transform.localRotation = Quaternion.identity;
        }
    }

    void Start()
    {
        if (Random.Range(0, 10) <= 5)
        {
            transform.rotation = Quaternion.Euler(0, 0, 0);
        }
        else if (Random.Range(0, 10) >= 6)
        {
            transform.rotation = Quaternion.Euler(0, 180, 0);
        }

        InvokeRepeating("CrateRift", 0, 6);
    }


    void Update()
    {
        
    }
}
